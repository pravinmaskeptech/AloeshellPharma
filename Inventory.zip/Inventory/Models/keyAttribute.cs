﻿using System;

namespace Inventory.Models
{
    internal class keyAttribute : Attribute
    {
    }
}